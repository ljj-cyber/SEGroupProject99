package view;

import view.menuSelectSeat;

public class Test_menu {
    public static void main(String[] args) {
        menuSelectSeat p = new menuSelectSeat("8201465425955");
    }
}
