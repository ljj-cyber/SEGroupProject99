package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * This class is for selecting the foundation meal
 * @Author Tingyu Xie
 * @version 1.0
 */
public class menuSelectMeal {
    private JFrame frame0;//当前页面容器
    private JPanel panel0;
    private JButton buttonBack;
    private JButton buttonNext;
    private JPanel panelBot;
    private JPanel panelTop;
    private JLabel label2;
    private JLabel label1;
    private JLabel label3;
    private JLabel label4;
    private JComboBox comboBoxMeal;
    private JCheckBox checkBoxExtra;

    public menuSelectMeal(String orderId) {
        //生成页面区域
        frame0 = new JFrame("menuSelectMeal");
        ImageIcon img1 = new ImageIcon("img/meal1.png");
        img1.setImage(img1.getImage().getScaledInstance(250,150, Image.SCALE_DEFAULT));
        ImageIcon img2 = new ImageIcon("img/meal2.png");
        img2.setImage(img2.getImage().getScaledInstance(250,150, Image.SCALE_DEFAULT));
        ImageIcon img3 = new ImageIcon("img/meal3.png");
        img3.setImage(img3.getImage().getScaledInstance(250,150, Image.SCALE_DEFAULT));
        ImageIcon img4 = new ImageIcon("img/meal4.png");
        img4.setImage(img4.getImage().getScaledInstance(250,150, Image.SCALE_DEFAULT));
        label1.setIcon(img1);
        label2.setIcon(img2);
        label3.setIcon(img3);
        label4.setIcon(img4);
        frame0.setContentPane(panel0);
        frame0.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame0.pack();
        frame0.setVisible(true);
        frame0.setSize(800,500);

        //监听事件区域
        buttonBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("back");


                //跳转回座位选择界面
                new menuSelectSeat(orderId);
                frame0.dispose();
            }
        });
        buttonNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("next");
                //提取、存储相关数据



                //跳转到额外选餐或者展示值机信息界面    未考虑特殊座位
                if(checkBoxExtra.isSelected()){
                    new menuSelectExtraMeal(orderId);
                }
                else {
                    new menuShowInfo(orderId);
                }

                frame0.dispose();
            }
        });
    }

    //测试用
    public static void main(String[] args) {
       new menuSelectMeal("8201465425955");
    }
}
