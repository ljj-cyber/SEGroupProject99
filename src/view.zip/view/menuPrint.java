package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Show all information and print.
 * This interface will show the Boarding pass , Carry-on tag and its checked information card . They can be printed.
 * @Author Tianze Li
 * @version 1.0
 */
public class menuPrint {
    private JFrame frame0;
    private JPanel panel0;
    private JButton buttonPrint;
    private JTextArea textAreaPass;
    private JTextArea textAreaCard;
    private JTextArea textAreaTag;


    public menuPrint(String orderId) {
        //页面生成区域
        frame0 = new JFrame("menuPrint");
        frame0.setContentPane(panel0);
        frame0.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame0.pack();
        frame0.setVisible(true);
        frame0.setSize(800,500);


        //事件监听区域
        buttonPrint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Print successfully");
            }
        });
    }


    //测试用
    public static void main(String[] args) {

    }
}
