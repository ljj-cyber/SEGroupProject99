package view;

import view.Choose;

public class Test {
    public static void main(String[] args) {
        Choose c = new Choose();
    }
}
