package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class menuSelectExtraMeal {
    private JFrame frame0;
    private JPanel panel0;
    private JButton buttonBack;
    private JButton buttonNext;
    private JCheckBox hamburgerCheckBox;
    private JCheckBox beefCheckBox;
    private JCheckBox coffeeCheckBox;
    private JCheckBox juiceCheckBox;

    public menuSelectExtraMeal(String orderId) {
        frame0 = new JFrame("menuSelectExtraMeal");
        frame0.setContentPane(panel0);
        frame0.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame0.pack();
        frame0.setVisible(true);
        frame0.setSize(800,500);

        buttonBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new menuSelectMeal(orderId);
                frame0.dispose();

            }
        });
        buttonNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(true){

                }
                else {

                }

            }
        });
    }


    public static void main(String[] args) {
        new menuSelectExtraMeal("");
    }
}
